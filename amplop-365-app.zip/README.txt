AMPLOP 365 QUEST - paket aplikasi (PWA)

ISI: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png

CARA PASANG DI HP (gratis):
1. Upload SEMUA file ke hosting statis, contohnya Netlify Drop (app.netlify.com/drop),
   GitHub Pages, atau Cloudflare Pages. Harus lewat https.
2. Buka link-nya di HP.
   - Android (Chrome): menu titik tiga > "Instal aplikasi" / "Tambahkan ke layar utama"
   - iPhone (Safari): tombol Bagikan > "Tambah ke Layar Utama"
3. Aplikasi muncul di layar utama, buka layar penuh, dan bisa jalan offline.

CATATAN:
- Data tabungan tersimpan di browser HP itu saja (tidak ada sinkron/backup antar perangkat).
  Jangan hapus data browser/situs.
- Kalau mengubah index.html, naikkan nama cache di sw.js (amplop365-v1 jadi v2) biar ter-update.
- Font Google dimuat saat online pertama kali, lalu tersimpan untuk offline.
